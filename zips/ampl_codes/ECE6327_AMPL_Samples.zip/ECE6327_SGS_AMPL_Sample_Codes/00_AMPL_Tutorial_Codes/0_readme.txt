The example AMPL codes in this folder is the same with the sample codes at:
https://github.com/rpglab/ECE6379_PSOM_AMPL_Sample_Codes/tree/main/00_AMPL_Tutorial_Codes