package psseraw.elements;

import psseraw.PsseRawModel;

public class PhaseShifter2List extends Transformer2List {

	public PhaseShifter2List(PsseRawModel model) {super(model);}
	

}
