package psseraw.elements;

import psseraw.PsseRawModel;

/**
 * 
 * @author Xingpeng Li (xplipower@gmail.com)
 *         Website: https://rpglab.github.io/
 *
 */
public class PhaseShifter2List extends Transformer2List {

	public PhaseShifter2List(PsseRawModel model) {super(model);}
	

}
