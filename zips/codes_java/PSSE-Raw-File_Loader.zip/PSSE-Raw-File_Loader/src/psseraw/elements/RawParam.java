package psseraw.elements;

public class RawParam {

	private static double _systemBaseMVA = 100;
	
	public static double getSystemBaseMVA() {return _systemBaseMVA;}
}
