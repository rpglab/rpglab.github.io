package psseraw.elements;

import psseraw.PsseRawModel;

public class PhaseShifter3List extends Transformer3List {

	public PhaseShifter3List(PsseRawModel model) {super(model);}

}
