package psseraw.elements;

import psseraw.PsseRawModel;

/**
 * 
 * @author Xingpeng Li (xplipower@gmail.com)
 *         Website: https://rpglab.github.io/
 *
 */
public class PhaseShifter3List extends Transformer3List {

	public PhaseShifter3List(PsseRawModel model) {super(model);}

}
